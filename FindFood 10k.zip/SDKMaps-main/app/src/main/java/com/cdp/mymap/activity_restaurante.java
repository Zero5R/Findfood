package com.cdp.mymap;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class activity_restaurante extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurante_view);
    }
}
