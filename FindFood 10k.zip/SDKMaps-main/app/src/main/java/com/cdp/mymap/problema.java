package com.cdp.mymap;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class problema extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.problem);
    }
}
